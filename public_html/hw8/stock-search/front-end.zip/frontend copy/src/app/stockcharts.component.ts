import { Component, Input } from '@angular/core';

@Component({
    selector: 'stockcharts',
    template: `
    <chart *ngIf="!isError" [type]="chartType" [options]="options"></chart>
    <div *ngIf="isError" class="alert alert-danger" role="alert">Error! Failed to get {{flag}} data.</div>
    <div *ngIf="inProgress" class="progress">
                                <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100"
                                    style="width: 45%">
                                    <span class="sr-only">45% Complete</span>
                                </div>
    </div>
  `,
    styleUrls: ['./app.component.css']
})
export class StockChartsComponent {
    @Input() chartData:any;
    @Input() flag:any;
    @Input() isClick:boolean;
    options: Object;
    inProgress = true;
    chartType = "chart";
    isError = false;
    constructor() {}
ngOnInit(){
    
}
    ngOnChanges() {
        if ( this.chartData != undefined) {
            this.inProgress = this.isClick;
            // console.log(this.inProgress);
            if (this.chartData.hasOwnProperty("Error Message")){
                this.isError = true;
            } else {
                // console.log(this.chartData);
                this.isError = false;
                console.log(this.flag);
                if(this.flag === 'history'){//draw history
                    this.chartType = "StockChart";
                    this.drawHistory();
                } else if(this.flag === 'Price'){
                    this.drawPrice();
                } else if(this.flag === 'SMA'||'EMA'||'STOCH'||'RSI'||'ADX'||'CCI'||'BBANDS'||'MACD'){
                    var indicatorMetaData = this.chartData['Meta Data'];
                    var dataArrays = Object.values(this.chartData['Technical Analysis: ' + this.flag]);
                    var dates = Object.keys(this.chartData['Technical Analysis: ' + this.flag]);
                    //set days for xAxis
                    var days = new Array();
                    for (var i = 0; i < 130; i++) {
                        dates[i] = dates[i].replace(/-/g, "/");
                        var x = new Date(dates[i]);
                        var y = (x.getMonth() < 9 ? "0" : "") + (x.getMonth() + 1) + "/" + (x.getDate() < 10 ? "0" : "") + (x.getDate());
                        days.push(y);
                    }
                    days.reverse();
                    if (this.flag == 'STOCH') {
                        var slowD = new Array();
                        var slowK = new Array();
                        for (var i = 0; i < 130; i++) {
                            slowD.push(dataArrays[i]['SlowD']);
                            slowK.push(dataArrays[i]['SlowK']);
                        }
                        slowD = slowD.map(Number);
                        slowK = slowK.map(Number);
                        slowD.reverse();
                        slowK.reverse();
                        //draw chart
                        this.drawStoch(days, slowD, slowK);
                    } else if (this.flag == 'BBANDS') {
                        var lowerBand = new Array();
                        var middleBand = new Array();
                        var upperBand = new Array();
                        for (var i = 0; i < 130; i++) {
                            lowerBand.push(dataArrays[i]['Real Lower Band']);
                            middleBand.push(dataArrays[i]['Real Middle Band']);
                            upperBand.push(dataArrays[i]['Real Upper Band']);
                        }
                        lowerBand = lowerBand.map(Number);
                        middleBand = middleBand.map(Number);
                        upperBand = upperBand.map(Number);
                        lowerBand.reverse();
                        middleBand.reverse();
                        upperBand.reverse();
                        //draw chart
                        this.drawBbands(days, lowerBand, middleBand, upperBand);
                    } else if (this.flag == 'MACD') {
                        var macd = new Array();
                        var macdHist = new Array();
                        var macdSignal = new Array();
                        for (var i = 0; i < 130; i++) {
                            macd.push(dataArrays[i]['MACD']);
                            macdHist.push(dataArrays[i]['MACD_Hist']);
                            macdSignal.push(dataArrays[i]['MACD_Signal']);
                        }
                        macd = macd.map(Number);
                        macdHist = macdHist.map(Number);
                        macdSignal = macdSignal.map(Number);
                        macd.reverse();
                        macdHist.reverse();
                        macdSignal.reverse();
                        //draw chart
                        this.drawMacd(days, macd, macdHist, macdSignal);
                    } else {
                        var indicatorData = new Array();
                        for (var i = 0; i < 130; i++) {
                            indicatorData.push(dataArrays[i][this.flag]);
                        }
                        indicatorData = indicatorData.map(Number);
                        indicatorData.reverse();
                        //draw char
                        this.drawOneLine(days, indicatorData);
                    }                 
                }
            }
        }else {
        //progress bar
        }
    }

    drawHistory() {
        this.inProgress = false;
        this.options = this.chartData['history options'];
        console.log(this.options);
    }

    drawPrice() {
        console.log("drawPriceChart...");
        this.inProgress = false;
        this.options = this.chartData['options'];
       
    }

    drawOneLine(xData, yData) {
    // console.log(xData);
    // console.log(yData);
    this.inProgress = false;
    this.options = {
            chart: {
                type: 'line',
                zoomType: 'x'
            },
            title: {
                text: this.chartData['Meta Data']['2: Indicator']
            },

            subtitle: {
                text: '<a href=" https://www.alphavantage.co/" target="_blank">Source: Alpha Vantage</a>',
                useHTML: true,
                style: {
                    color: "blue"
                }
            },

            yAxis: {
                title: {
                    text: this.flag
                }
            },
            xAxis: {
                categories: xData,
                tickInterval: 5
            },

            plotOptions: {
                series: {
                    label: {
                        connectorAllowed: false
                    },
                }
            },

            series: [{
                color: '#eb4d47',
                name: this.chartData['Meta Data']['1: Symbol'],
                data: yData
            }]
        }
    }

    drawStoch(xData, yData1, yData2) {
        // console.log(xData);
        // console.log(yData1);
        // console.log(yData2);
        this.inProgress = false;
        this.options = {
            chart: {
                type: 'line',
                zoomType: 'x'
            },
            title: {
                text: this.chartData['Meta Data']['2: Indicator']
            },

            subtitle: {
                text: '<a href=" https://www.alphavantage.co/" target="_blank">Source: Alpha Vantage</a>',
                useHTML: true,
                style: {
                    color: "blue"
                }
            },

            yAxis: {
                title: {
                    text: this.flag
                }
            },
            xAxis: {
                categories: xData,
                tickInterval: 5
            },

            plotOptions: {
                series: {
                    label: {
                        connectorAllowed: false
                    },
                }
            },

            series: [{
                color: '#eb4d47',
                name: this.chartData['Meta Data']['1: Symbol'] + ' slowD',
                data: yData1
            }, {
                name: this.chartData['Meta Data']['1: Symbol'] + ' slowK',
                data: yData2
            }]

        }
    }//drawStoch

    drawBbands(xData, yData1, yData2, yData3) {
        // console.log(xData);
        // console.log(yData1);
        // console.log(yData2);
        // console.log(yData3);
        this.inProgress = false;
        this.options = {
            chart: {
                type: 'line',
                zoomType: 'x'
            },
            title: {
                text: this.chartData['Meta Data']['2: Indicator']
            },

            subtitle: {
                text: '<a href=" https://www.alphavantage.co/" target="_blank">Source: Alpha Vantage</a>',
                useHTML: true,
                style: {
                    color: "blue"
                }
            },

            yAxis: {
                title: {
                    text: this.flag
                }
            },
            xAxis: {
                categories: xData,
                tickInterval: 5
            },

            plotOptions: {
                series: {
                    label: {
                        connectorAllowed: false
                    },
                }
            },

            series: [{
                color: '#eb4d47',
                name: this.chartData['Meta Data']['1: Symbol'] + ' Real Lower Band',
                data: yData1
            }, {
                name: this.chartData['Meta Data']['1: Symbol'] + ' Real Middle Band',
                data: yData2
            }, {
                name: this.chartData['Meta Data']['1: Symbol'] + ' Real Upper Band',
                data: yData3
            }]

        }
    }//drawBbands

    drawMacd(xData, yData1, yData2, yData3) {
        // console.log(xData);
        // console.log(yData1);
        // console.log(yData2);
        // console.log(yData3);
        this.inProgress = false;
        this.options = {
            chart: {
                type: 'line',
                zoomType: 'x'
            },
            title: {
                text: this.chartData['Meta Data']['2: Indicator']
            },

            subtitle: {
                text: '<a href=" https://www.alphavantage.co/" target="_blank">Source: Alpha Vantage</a>',
                useHTML: true,
                style: {
                    color: "blue"
                }
            },

            yAxis: {
                title: {
                    text: this.flag
                }
            },
            xAxis: {
                categories: xData,
                tickInterval: 5
            },

            plotOptions: {
                series: {
                    label: {
                        connectorAllowed: false
                    },
                }
            },

            series: [{
                color: '#eb4d47',
                name: this.chartData['Meta Data']['1: Symbol'] + ' MACD',
                data: yData1
            }, {
                name: this.chartData['Meta Data']['1: Symbol'] + ' MACD_Hist',
                data: yData2
            }, {
                name: this.chartData['Meta Data']['1: Symbol'] + ' MACD_Signal',
                data: yData3
            }]

        }
    }//drawMacd



}
