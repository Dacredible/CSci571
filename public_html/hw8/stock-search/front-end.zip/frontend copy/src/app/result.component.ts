import { Component,Input } from '@angular/core';
import { WebService } from "./web.service";
import { SearchComponent } from "./search.component";
declare var jquery: any;
declare var $: any;
declare var FB: any;
@Component({
    selector: 'result',
    templateUrl: './result.component.html'
})

export class ResultComponent {
    @Input() isClick : any;

    isLeftVisible = true;
    isSucceed = false;
    newsData: any;
    inProgress = false;
    newsInProgress = false;
    priceData;
    smaData;
    emaData;
    stochData;
    rsiData;
    adxData;
    cciData;
    bbandsData;
    macdData;
    
    header="Stock Details";
    
    color = 'red';
    imgUrl = '';
    news;

    isPriceError = false;
    isNewsError = false;
    favlist = [];
    favlist1=[
        {
            "symbol":"MSFT",
            "price":"90",
            "change":"12",
            "volume":"1232891"
        },
        {
            "symbol": "AAPL",
            "price": "120",
            "change": "20",
            "volume":"238192"
        }
    ];
    
    constructor(private webService: WebService) {  
    }


    ngOnInit() {
        this.initTabs();

        this.webService.priceObserv.subscribe(priceData => {
            this.priceData = priceData;
            if (this.priceData.hasOwnProperty("Error Message")) {
                this.isPriceError = this.showError();
            } else {
                this.isPriceError = false;
                this.drawPriceTable();
                
            }
        });

        this.webService.smaObserv.subscribe(smaData => {
            this.smaData = smaData;
        });

        this.webService.emaObserv.subscribe(emaData => {
            this.emaData = emaData;
        });

        this.webService.stochObserv.subscribe(stochData => {
            this.stochData = stochData;
        });

        this.webService.rsiObserv.subscribe(rsiData => {
            this.rsiData = rsiData;
        });
        
        this.webService.adxObserv.subscribe(adxData => {
            this.adxData = adxData;
        });

        this.webService.cciObserv.subscribe(cciData => {
            this.cciData = cciData;
        });

        this.webService.bbandsObserv.subscribe(bbandsData => {
            this.bbandsData = bbandsData;
        });

        this.webService.macdObserv.subscribe(macdData => {
            this.macdData = macdData;
        });

        this.webService.newsObserv.subscribe(newsData => {
            this.newsData = newsData;
            if(this.newsData.hasOwnProperty("Error Message")){
                this.isNewsError = this.showError();
                console.log(this.isNewsError);
            } else {
                this.isNewsError = false;
                this.drawNewsTable();
            }
        });

    }

    ngOnChanges() {
        this.isLeftVisible = !this.isClick;
        this.inProgress = this.isClick;
        this.newsInProgress = this.isClick;
    }

    drawPriceTable() {
        if (this.priceData != undefined) {
            console.log("Drawing Price Table...");
            this.inProgress = false;
            this.isSucceed = true;
            
            if (this.priceData["Change"] > 0) {
                this.color = "green";
                this.imgUrl = "http://cs-server.usc.edu:45678/hw/hw8/images/Up.png";
            } else {
                this.color = "red";
                this.imgUrl = "http://cs-server.usc.edu:45678/hw/hw8/images/Down.png";
            }
            
        }
    }

    drawNewsTable() {
        if (this.newsData != undefined && !this.isNewsError) {
            this.newsInProgress = false;
            this.newsData = this.newsData.rss.channel[0].item;
            // console.log(this.newsData);
            this.news = new Array();
            for (var i = 0; i < this.newsData.length; i++) {
                if (this.newsData[i].link[0].includes('article')) {
                    this.news.push(this.newsData[i]);
                }
                if (this.news.length >= 5) break;
            }
            // console.log(this.news);
        }
        
    }

    changeColor() {
        return this.color;
    }
    initTabs() {
        $('.nav a').click(function (e) {
            e.preventDefault()
            $(this).tab('show')
        })
    }

    numberWithCommas(x) {
    return x.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

    showError(){
        return true;
    }

    postFB(){
        var options = {
            "xAxis": {
                "categories": ["Jan", "Feb", "Mar"]
            },
            "series": [{
                "data": [29.9, 71.5, 106.4]
            }]};
        this.webService.postHighChart(options);

    }

    // addFav() {
    //     localStorage.setItem(this.symbol, this.symbol);
    //     let localSymbol = localStorage.getItem(this.symbol);

    // }
}
