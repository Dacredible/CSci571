import { Http } from "@angular/http";
import { Injectable } from "@angular/core";
import { Subject } from "rxjs/Rx";
import { Observable } from 'rxjs';
import { Response } from "@angular/http/src/static_response";
declare var FB: any;
@Injectable()
export class WebService {
    // BASE_URL = 'http://localhost:3000/api/';
    BASE_URL = "http://stocksearch.us-east-2.elasticbeanstalk.com/api/";

    private priceData;
    private smaData;
    private emaData;
    private stochData;
    private rsiData;
    private adxData;
    private cciData;
    private bbandsData;
    private macdData;
    private newsData;
    private completeData;
    private chartURL;

    private priceSubject = new Subject();
    private smaSubject = new Subject();
    private emaSubject = new Subject();
    private stochSubject = new Subject();
    private rsiSubject = new Subject();
    private adxSubject = new Subject();
    private cciSubject = new Subject();
    private bbandsSubject = new Subject();
    private macdSubject = new Subject();
    private newsSubject = new Subject();
    private completeSubject = new Subject();
    private chartSubject = new Subject();

    priceObserv = this.priceSubject.asObservable();
    smaObserv = this.smaSubject.asObservable();
    emaObserv = this.emaSubject.asObservable();
    stochObserv = this.stochSubject.asObservable();
    rsiObserv = this.rsiSubject.asObservable();
    adxObserv = this.adxSubject.asObservable();
    cciObserv = this.cciSubject.asObservable();
    bbandsObserv = this.bbandsSubject.asObservable();
    macdObserv = this.macdSubject.asObservable();
    newsObserv = this.newsSubject.asObservable();
    completeObserv = this.completeSubject.asObservable();
    chartObserv = this.chartSubject.asObservable();

    errorMessage = {
        'Error Message': "unable to get message"
    }
    constructor(private http: Http) {
        
    }

    getPrice(symbol) {
        this.http.get(this.BASE_URL + 'price?stockSymbol=' + symbol).subscribe(response => {
            this.priceData = response.json();
            this.priceSubject.next(this.priceData);
        }, error => {
            this.handleError("Unable to get messages for Price", this.priceSubject);
            
        });
    }
    getSma(symbol) {
        this.http.get(this.BASE_URL + 'sma?stockSymbol=' + symbol).subscribe(response => {
            this.smaData = response.json();
            this.smaSubject.next(this.smaData);
        }, error => {
            this.handleError("Unable to get messages for SMA", this.smaSubject);

        });
    }
    getEma(symbol) {
        this.http.get(this.BASE_URL + 'ema?stockSymbol=' + symbol).subscribe(response => {
            this.emaData = response.json();
            this.emaSubject.next(this.emaData);
        }, error => {
            this.handleError("Unable to get messages for EMA", this.emaSubject);

        });
    }
    getStoch(symbol) {
        this.http.get(this.BASE_URL + 'stoch?stockSymbol=' + symbol).subscribe(response => {
            this.stochData = response.json();
            this.stochSubject.next(this.stochData);
        }, error => {
            this.handleError("Unable to get messages for STOCH", this.stochSubject);

        });
    }
    getRsi(symbol) {
        this.http.get(this.BASE_URL + 'rsi?stockSymbol=' + symbol).subscribe(response => {
            this.rsiData = response.json();
            this.rsiSubject.next(this.rsiData);
        }, error => {
            this.handleError("Unable to get messages for RSI", this.rsiSubject);

        });
    }
    getAdx(symbol) {
        this.http.get(this.BASE_URL + 'adx?stockSymbol=' + symbol).subscribe(response => {
            this.adxData = response.json();
            this.adxSubject.next(this.adxData);
        }, error => {
            this.handleError("Unable to get messages for ADX", this.adxSubject);

        });
    }
    getCci(symbol) {
        this.http.get(this.BASE_URL + 'cci?stockSymbol=' + symbol).subscribe(response => {
            this.cciData = response.json();
            this.cciSubject.next(this.cciData);
        }, error => {
            this.handleError("Unable to get messages for CCI", this.cciSubject);

        });
    }
    getBbands(symbol) {
        this.http.get(this.BASE_URL + 'bbands?stockSymbol=' + symbol).subscribe(response => {
            this.bbandsData = response.json();
            this.bbandsSubject.next(this.bbandsData);
        }, error => {
            this.handleError("Unable to get messages for BBANDS", this.macdSubject);

        });
    }
    getMacd(symbol) {
        this.http.get(this.BASE_URL + 'macd?stockSymbol=' + symbol).subscribe(response => {
            this.macdData = response.json();
            this.macdSubject.next(this.macdData);
        }, error => {
            this.handleError("Unable to get messages for MACD", this.macdSubject);

        });
    }
    getNews(symbol) {
        this.http.get(this.BASE_URL + 'news?stockSymbol=' + symbol).subscribe(response => {
            this.newsData = response.json();
            // console.log("json from web.service: this.newsData ");
            // console.log(this.newsData)
            this.newsSubject.next(this.newsData);
        }, error => {
            this.handleError("Unable to get messages for news", this.newsSubject);

        });
    }

    autoComplete(symbol) {
        this.http.get(this.BASE_URL + 'complete?stockSymbol=' + symbol).subscribe(response => {
            this.completeData = response.json();
            this.completeSubject.next(this.completeData);
        },error => {

        });
    }

    postHighChart(option) {
        var data = {
            options: JSON.stringify(option),
            async: true,
            type: "png",
            width: 400,
        };
        this.http.post(this.BASE_URL + 'highchart',data).subscribe(response => {
            this.chartURL = response['_body'];
            console.log(this.chartURL);
            FB.ui({
                app_id: '141421073164578',
                method: 'feed',
                picture: this.chartURL
            }, (response) => {
                if (response && !response.error_message) {

                }else{

                }
                });


            // FB.ui({
            //     method: 'feed',
            //     link: 'https://developers.facebook.com/docs/',
            //     caption: 'An example caption',
            // }, function (response) { });
        }, error => {

        });

        
    }
    private handleError(error,sub) {
        console.error(error);
        sub.next(this.errorMessage);
    }
    


}