import { Component } from '@angular/core';

import { SearchComponent } from "./search.component";
import { ResultComponent } from "./result.component";
@Component({
  selector: 'app-root',
  template: `
  <search></search>

  `,
  // templateUrl:'./app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
}
