import { Component,Input } from '@angular/core';
import { WebService } from "./web.service";
import { SearchComponent } from "./search.component";
declare var jquery: any;
declare var $: any;
declare var FB: any;
@Component({
    selector: 'result',
    templateUrl: './result.component-slide-all-div.html'
})

export class ResultComponent {
    @Input() isClick : any;

    isLeftVisible = true;
    isSucceed = false;
    newsData: any;
    inProgress = false;
    newsInProgress = false;
    priceData;
    smaData;
    emaData;
    stochData;
    rsiData;
    adxData;
    cciData;
    bbandsData;
    macdData;
    
    header="Stock Details";
    symbol = '';
    dates = [];
    today = '';
    timestamp;
    today_close = '';
    previous_close = '';
    open = '';
    low = '';
    high = '';
    volume = '';
    change = '';
    change_percent = '';
    color = 'red';
    imgUrl = '';
    news;

    isPriceError = false;
    isNewsError = false;
    favlist = [];
    favlist1=[
        {
            "symbol":"MSFT",
            "price":"90",
            "change":"12",
            "volume":"1232891"
        },
        {
            "symbol": "AAPL",
            "price": "120",
            "change": "20",
            "volume":"238192"
        }
    ];
    
    constructor(private webService: WebService) {  
    }


    ngOnInit() {
        this.initTabs();

        this.webService.priceObserv.subscribe(priceData => {
            this.priceData = priceData;
            if (this.priceData.hasOwnProperty("Error Message")) {
                this.isPriceError = this.showError();
            } else {
                this.isPriceError = false;
                this.drawPriceTable();
                
            }
        });

        this.webService.smaObserv.subscribe(smaData => {
            this.smaData = smaData;
        });

        this.webService.emaObserv.subscribe(emaData => {
            this.emaData = emaData;
        });

        this.webService.stochObserv.subscribe(stochData => {
            this.stochData = stochData;
        });

        this.webService.rsiObserv.subscribe(rsiData => {
            this.rsiData = rsiData;
        });
        
        this.webService.adxObserv.subscribe(adxData => {
            this.adxData = adxData;
        });

        this.webService.cciObserv.subscribe(cciData => {
            this.cciData = cciData;
        });

        this.webService.bbandsObserv.subscribe(bbandsData => {
            this.bbandsData = bbandsData;
        });

        this.webService.macdObserv.subscribe(macdData => {
            this.macdData = macdData;
        });

        this.webService.newsObserv.subscribe(newsData => {
            this.newsData = newsData;
            if(this.newsData.hasOwnProperty("Error Message")){
                this.isNewsError = this.showError();
                console.log(this.isNewsError);
            } else {
                this.isNewsError = false;
                this.drawNewsTable();
            }
        });

    }

    ngOnChanges() {
        this.isLeftVisible = !this.isClick;
        this.inProgress = this.isClick;
        this.newsInProgress = this.isClick;
    }

    drawPriceTable() {
        if (this.priceData != undefined) {
            console.log("Drawing Price Table...");
            this.inProgress = false;
            this.isSucceed = true;
            this.symbol = this.priceData['Meta Data']['2. Symbol'];
            this.dates = Object.keys(this.priceData["Time Series (Daily)"]);
            this.today = this.dates[0];
            let lastRefresh = this.priceData['Meta Data']['3. Last Refreshed'];
            if (lastRefresh.includes(' ')){
                this.timestamp = lastRefresh + " EST";
            } else {
                this.timestamp = this.today + " 16:00:00 EST";
            }
            this.today_close = parseFloat(this.priceData['Time Series (Daily)'][this.today]['4. close']).toFixed(2);
            this.previous_close = parseFloat(this.priceData['Time Series (Daily)'][this.dates[1]]['4. close']).toFixed(2);
            this.open = parseFloat(this.priceData['Time Series (Daily)'][this.today]['1. open']).toFixed(2);
            this.low = parseFloat(this.priceData['Time Series (Daily)'][this.today]['3. low']).toFixed(2);
            this.high = parseFloat(this.priceData['Time Series (Daily)'][this.today]['2. high']).toFixed(2);
            var volumeTemp = this.priceData['Time Series (Daily)'][this.today]['5. volume'];
            this.volume = this.numberWithCommas(volumeTemp);
            this.change = (parseFloat(this.today_close) - parseFloat(this.previous_close)).toFixed(2);
            this.change_percent = ((parseFloat(this.change) / parseFloat(this.previous_close)) * 100).toFixed(2);
            if ((parseFloat(this.today_close) - parseFloat(this.previous_close)) > 0) {
                this.color = "green";
                this.imgUrl = "http://cs-server.usc.edu:45678/hw/hw8/images/Up.png";
            } else {
                this.color = "red";
                this.imgUrl = "http://cs-server.usc.edu:45678/hw/hw8/images/Down.png";
            }
            
        }
    }

    drawNewsTable() {
        if (this.newsData != undefined && !this.isNewsError) {
            this.newsInProgress = false;
            this.newsData = this.newsData.rss.channel[0].item;
            // console.log(this.newsData);
            this.news = new Array();
            this.news = [];
            for (var i = 0; i < this.newsData.length; i++) {
                if (this.newsData[i].link[0].includes('article')) {
                    this.news.push(this.newsData[i]);
                    
                }
                if (this.news.length >= 5) break;
            }

            for(var i = 0; i<this.news.length;i++){
                this.news[i].pubDate[0] = this.news[i].pubDate[0].substring(0, this.news[i].pubDate[0].indexOf('-'));
                this.news[i].pubDate[0] += " EST";
            }

            console.log(this.news);
        }
        
    }

    changeColor() {
        return this.color;
    }
    initTabs() {
        $('.nav a').click(function (e) {
            e.preventDefault()
            $(this).tab('show')
        })
    }

    numberWithCommas(x) {
    return x.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

    showError(){
        return true;
    }

    postFB(){
        var options = {
            "xAxis": {
                "categories": ["Jan", "Feb", "Mar"]
            },
            "series": [{
                "data": [29.9, 71.5, 106.4]
            }]};
        this.webService.postHighChart(options);

    }

    addFav() {
        var obj = {
            "symbol":this.symbol,
            "price":this.today_close,
            "change":this.change,
            "change_percent":this.change_percent,
            "imgUrl":this.imgUrl,
            "color":this.color,
            "volume":this.volume
        }

        localStorage.setItem(this.symbol, JSON.stringify(obj));
        let localObj = JSON.parse(localStorage.getItem(this.symbol));
        this.favlist.push(localObj);
    }

    delete(mark) {
        for(var i = 0; i<this.favlist.length;i++){
            if(this.favlist[i]['symbol'].includes(mark)){
                this.favlist.splice(i,1);
                localStorage.removeItem(this.symbol);
            }
        }
    }
}
