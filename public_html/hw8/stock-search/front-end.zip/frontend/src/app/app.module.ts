import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from "@angular/http";
import { FormsModule } from "@angular/forms";
import { HighchartsStatic } from 'angular2-highcharts/dist/HighchartsService';
import { MatAutocompleteModule } from "@angular/material";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { SlidePanelComponent } from './slide-panel.component';
import { WebService } from "./web.service";
import { AppComponent } from './app.component';
import { SearchComponent } from "./search.component";
import { ResultComponent } from "./result.component";
import { StockChartsComponent } from "./stockcharts.component";
import { ChartModule } from "angular2-highcharts";

declare var require: any;
export function highchartsFactory() {
  //return require('highcharts');
  const hc = require('highcharts');
  const dd = require('highcharts/modules/drilldown');
  const ex = require('highcharts/modules/exporting');
  const st = require('highcharts/modules/stock');

  dd(hc);
  ex(hc);
  st(hc);
  return hc;
}

@NgModule({
  declarations: [
    AppComponent,
    SearchComponent,
    ResultComponent,
    StockChartsComponent,
    SlidePanelComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpModule,
    FormsModule,
    ChartModule,
    MatAutocompleteModule
  ],
  providers: [WebService, { provide: HighchartsStatic, useFactory: highchartsFactory }],
  bootstrap: [AppComponent]
})
export class AppModule { }
