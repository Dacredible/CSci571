import { Component } from '@angular/core';
import { WebService } from "./web.service";
import { ResultComponent } from "./result.component";
import { Subscription } from 'rxjs/Subscription';

@Component({
    selector: 'search',
    templateUrl:'./search.component.html'
})
export class SearchComponent {
    autoCompleteData : any;
    isEmpty = false; // First time doesn't detect input field
    subject;
    isClick = false;
    constructor(private webService: WebService){}

    symbol = '';
    searchStock() {
        console.log("symbol: " + this.symbol);
        this.searchPrice();
        this.searchSma();
        this.searchEma();
        this.searchStoch();
        this.searchRsi();
        this.searchAdx();
        this.searchCci();
        this.searchBbands();
        this.searchMacd();
        this.searchNews();
        this.isClick = true;
    }

    searchPrice(){
        this.webService.getPrice(this.symbol);
    }
    searchSma() {
        this.webService.getSma(this.symbol);
    }
    searchEma() {
        this.webService.getEma(this.symbol);
    }
    searchStoch() {
        this.webService.getStoch(this.symbol);
    }
    searchRsi() {
        this.webService.getRsi(this.symbol);
    }
    searchAdx() {
        this.webService.getAdx(this.symbol);
    }
    searchCci() {
        this.webService.getCci(this.symbol);
    }
    searchBbands() {
        this.webService.getBbands(this.symbol);
    }
    searchMacd() {
        this.webService.getMacd(this.symbol);
    }
    searchNews() {
        this.webService.getNews(this.symbol);
    }
    onKey(event:any) {
        var char = event.target.value;
        if (char.trim().length != 0){
            this.webService.autoComplete(char);
            this.subject = this.webService.completeObserv.subscribe(completeData => {
                this.autoCompleteData = completeData;
                // console.log(completeData);
                // console.log(this.symbol);
                // this.autoCompleteDropDown();
            this.isEmpty = false;
            });
        } else {
            this.isEmpty = true;
        }


        if(this.autoCompleteData = undefined){
            
        } else {
            
        }
    }

    detect() {
        if(this.symbol.trim().length == 0){
            this.isEmpty = true;
        } else {
            this.isEmpty = false;
        }
    }

    clear() {
        this.isClick = false;
        this.symbol ='';
    }

    autoCompleteDropDown() {
        this.subject.unsubscribe();
        console.log(this.autoCompleteData);
    }
}
